more tail.out | grep DIV | grep U* |grep Max|sed '/final/d'| awk -F'=' '{print $2}' > divu


more tail.out | grep Monitoring | grep Ux |grep y\(i\)=5| awk -F':' '{print $2}' > ux5  # postion=5
more tail.out | grep Monitoring | grep Ux |grep xsize\(2\)/2| awk -F':' '{print $2}' > ux2  # half of channel
more tail.out | grep Monitoring | grep Uy |grep y\(i\)=5| awk -F':' '{print $2}' > uy5
more tail.out | grep Monitoring | grep Uy |grep xsize\(2\)/2| awk -F':' '{print $2}' > uy2
more tail.out | grep Monitoring | grep Uz |grep y\(i\)=5| awk -F':' '{print $2}' > uz5
more tail.out | grep Monitoring | grep Uz |grep xsize\(2\)/2| awk -F':' '{print $2}' > uz2
more tail.out | grep zhao | awk '{print $2,$3,$4}' > stretching

#gnuplot monitorFLOWRATE.gnu
gnuplot monitorDivU.gnu
#gnuplot monitorRxx2.gnu
#gnuplot monitorAverageU2.gnu
#gnuplot monitorRxx5.gnu
#gnuplot monitorAverageU5.gnu


gnuplot monitorux5.gnu
gnuplot monitorux2.gnu
gnuplot monitoruy5.gnu
gnuplot monitoruy2.gnu
gnuplot monitoruz5.gnu
gnuplot monitoruz2.gnu

gnuplot monitorstretching.gnu
