cd /home/newtest2014-6-18 && more tail.out |grep Time|awk '{print $4}' |tail -1|cut -c 1-5 |awk '{cmd="mkdir step"$1;system(cmd);system("sh image.sh");cmd2="mv *.png step"$1;system(cmd2);}'
