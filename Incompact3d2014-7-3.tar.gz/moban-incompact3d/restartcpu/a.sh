mpirun -np 8 incompact3d >> tail.out  &
