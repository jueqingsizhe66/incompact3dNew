cd /home/newtest2014-6-18/restartcpu && more tail.out |grep Time|awk '{print $4}' |tail -1|cut -c 1-5 |awk '{cmd="mkdir step"$1;system(cmd);system("sh image2.sh");cmd2="mv *.png  step"$1;system(cmd2);} END{cmd3="mv dudy* umean stress step"$1; system(cmd3)}'


#END{cmd3="mv dudy* umean stress step"$1; system(cmd3)}
