#monitor stage 1
cd /home/newtest2014-6-18/restartcpu && more tail.out |grep Time|awk '{print $4}' |tail -1|cut -c 1-5 |awk '{cmd="mkdir step"$1;system(cmd);system("sh image1.sh");cmd2="mv *.png dudy* step"$1;system(cmd2);}'


# in the monitor stage1: you don't need to add the End{} and use the image1.sh the same with monitor stage2
#statistics stage3
#cd /home/newtest2014-6-18/restartcpu && more tail.out |grep Time|awk '{print $4}' |tail -1|cut -c 1-5 |awk '{cmd="mkdir step"$1;system(cmd);system("sh image1.sh");cmd2="mv *.png dudy* step"$1;system(cmd2);} END{cmd3="mv dudy* umean stress step"$1; system(cmd3)}'



