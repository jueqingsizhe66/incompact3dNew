#!/bin/bash
#===============================================================================
#
#          FILE:  test.sh
# 
#         USAGE:  ./test.sh 
# 
#   DESCRIPTION:  
# 
#       OPTIONS:  ---
#  REQUIREMENTS:  ---
#          BUGS:  ---
#         NOTES:  ---
#        AUTHOR:  Ye Zhaoliang (YZL), zhaoturkkey@163.com
#       COMPANY:  NCEPU
#       VERSION:  1.0
#       CREATED:  2014年06月26日 20时05分12秒 CST
#      REVISION:  ---
#===============================================================================

gfortran stat.f90
./a.out
gnuplot ./test.gnu


